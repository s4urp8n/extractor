<?php
ob_implicit_flush(true);
ini_set('implicit_flush', 1);
error_reporting(E_ALL);

require "vendor/autoload.php";

$archives = \Zver\Common::getDirectoryContent('archives');

$all = 0;
$success = 0;

foreach ($archives as $archive) {

    if (\Zver\Extractor::isFileExtensionValid($archive)) {
        $all++;
        if (\Zver\Extractor::extract($archive)) {
            $success++;
        }
    }

}

echo "\nAll: " . $all . "\nSuccess: " . $success . "\nSuccess percentage: " . (int)(($success * 100) / $all) . "%\n";